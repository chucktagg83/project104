// Original list
let names = ["Freysy", "Sergio", "Dejan", "Timothy"];
let age = [31, 33, 23, 45, 45];

// Access the values -> position/index
names[2];
console.log(names[3]);

// Modify values
names[0] = "Aymen";
console.log(names);

// Add a value to the end of the array -> push
// 1. call the array w/o position
// 2. call the push method and 
// 3. provide the new value
names.push("Freysy");
console.log(names);

// Add a value to the beginning of the array -> unshift
names.unshift("Fernanda"); 
console.log(names);

// Remove the last item -> pop
// Ask Google: JavaScript Array Remove Last Item
names.pop();
console.log(names);

// Remove the first item -> shift
names.shift();
console.log(names);

// Remove item from specific position -> splice
// splice(position, how many?)
names.splice(1,2);
console.log(names);

console.log(` The first name is: ${names[0]}, the second name is ${names[1]}. `);