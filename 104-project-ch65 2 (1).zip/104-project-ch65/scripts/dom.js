function changeTitle(){
    // Testing
    // alert("Is connected!");

    // Get the HTML element with id="title" and store it in a variable
    let title = document.getElementById("title");

    // Change the text inside the title
    title.innerHTML = "Hello cohort 65!";

    // Get ALL the elements with class="text" and store them in a variable
    let paragraphs = document.getElementsByClassName("text");

    paragraphs[0].style.color = "blue";
    paragraphs[1].style.color = "red";
}

function addItem() {
    let inputValue = document.getElementById("itemInput").value;
    let list = document.getElementById("list");

    let li = document.createElement("li");
    
    li.innerHTML = inputValue;

    list.appendChild(li);

    inputValue.value = "";
}