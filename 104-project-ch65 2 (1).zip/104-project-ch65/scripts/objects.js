// Fernanda
let name = "Fernanda";
let lastname = "Murillo";
let email = "fmurillo@sdgku.edu";


// Timothy
let name2 = "Timothy";
let lastname2 = "Sailer";
let email2 = "timothy@sdgku.edu";

// Object Literal
let person1 = {
    name: "Fernanda",
    lastname: "Murillo",
    email: "fmurillo@sdgku.edu"
};

let person2 = {
    name: "Luis",
    lastname: "Perez",
    email: "lperez@sdgku.edu"
};

let person3 = {
    name: "Aprile",
    lastname: "Smith",
    email: "asmith@sdgku.edu"
};

// Access to the attributes of an objet
console.log(person1.name);

// Display the person names in the html/browser
let paragraph = document.createElement("p");
paragraph.innerHTML = person2.name;

document.body.appendChild(paragraph);

let personList = [person1, person2, person3];
console.log(personList[0].lastname);

// 1. Get the list
let list = document.getElementById("personList");

for(let i=0; i<personList.length; i++){
    // 2. Create the list item HTML element
    let li = document.createElement("li");

    // 3. Asign the person name to the list item
    li.innerHTML = `<b> ${personList[i].name} </b>`;

    // 4. Add the list item to the list
    list.appendChild(li);
}

// ======================
//     CONSTRUCTOR
// ======================

// The constructor
function Student(name, lastname, email){
    this.name = name;
    this.lastname = lastname;
    this.email = email;
}

// Create an object with the constructor
let student1 = new Student("Kate", "Frantz", 30);

// Print in the console the student's name
console.log(student1.name);